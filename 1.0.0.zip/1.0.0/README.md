# bitDuino10 (ATtiny10)
modified @maris_HY's bitDuino http://100year.cocolog-nifty.com/blog/2014/08/arduino-f0f0.html
